import Page from "./views/Merchant";

function App() {
  return (
    <div className="App">
      <Page />
    </div>
  );
}

export default App;
